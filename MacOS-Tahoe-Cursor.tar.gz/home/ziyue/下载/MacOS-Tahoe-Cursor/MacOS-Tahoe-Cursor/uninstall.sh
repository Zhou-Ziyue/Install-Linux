sudo rm -rf /usr/share/icons/MacOS-Tahoe-Cursor
